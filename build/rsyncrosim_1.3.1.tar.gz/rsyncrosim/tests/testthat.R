library(testthat)
library(rsyncrosim)

test_check("rsyncrosim")
